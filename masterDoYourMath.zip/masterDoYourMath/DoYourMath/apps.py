from django.apps import AppConfig


class DoyourmathConfig(AppConfig):
    name = 'DoYourMath'
